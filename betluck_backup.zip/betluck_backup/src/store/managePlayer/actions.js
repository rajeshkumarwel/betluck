import { MANAGEPLAYER_INFORMATION } from './types';

export function managePlayerInformation() {
    return {
        type: MANAGEPLAYER_INFORMATION,
    }
}