
export const ENDPOINTS = {

    loginPlayer: 'player/sendotp',
    loginPlayerVerification: 'player/validateotp',
    playerInformation: 'player/getone/',
    managePlayerList: 'player/getAllPlayers',
    addPlayer: 'player/save',
    deletePlayer: 'player/delete/',
    updatePlayername: 'player/updateName',
    updatePlayerupi: 'player/updateUpi'

    
}