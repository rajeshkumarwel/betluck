import React, { useEffect, useState} from "react";
import ManageTransactionPage from "./manageTransactionPage";

export default function ManageTransactionContainer() {

    return(
		<div className="wrapper">
			<ManageTransactionPage />		
		</div>
    )

}