import React, { useEffect, useState} from "react";
import DepositPage from "./depositPage";

export default function DepositContainer() {

    return(
		<div className="wrapper">
			<DepositPage />		
		</div>
    )

}