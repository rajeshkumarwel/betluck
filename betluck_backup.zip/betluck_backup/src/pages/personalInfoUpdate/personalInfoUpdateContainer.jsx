import React, { useEffect, useState} from "react";
import PersonalInfoUpdatePage from "./personalInfoUpdatePage";

export default function PersonalInfoUpdateContainer() {

    return(
		<div className="wrapper">
			<PersonalInfoUpdatePage />		
		</div>
    )

}