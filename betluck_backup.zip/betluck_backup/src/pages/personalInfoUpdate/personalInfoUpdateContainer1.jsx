import React, { useEffect, useState} from "react";
import PersonalInfoUpdatePage1 from "./personalInfoUpdatePage2";

export default function PersonalInfoUpdateContainer1() {

    return(
		<div className="wrapper">
			<PersonalInfoUpdatePage1 />		
		</div>
    )

}