import React, { useEffect, useState} from "react";
import PersonalInfoUpdatePage2 from "./personalInfoUpdatePage2";

export default function PersonalInfoUpdateContainer2() {

    return(
		<div className="wrapper">
			<PersonalInfoUpdatePage2 />		
		</div>
    )

}