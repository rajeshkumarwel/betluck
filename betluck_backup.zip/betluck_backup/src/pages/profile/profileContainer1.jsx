import React, { useEffect, useState} from "react";
import ProfilePage1 from "./profilePage1";

export default function ProfileContainer1() {

    return(
		<div className="wrapper">
			<ProfilePage1 />		
		</div>
    )

}