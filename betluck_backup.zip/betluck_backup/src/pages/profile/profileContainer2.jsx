import React, { useEffect, useState} from "react";
import ProfilePage2 from "./profilePage2";

export default function ProfileContainer2() {

    return(
		<div className="wrapper">
			<ProfilePage2 />		
		</div>
    )

}