import React, { useEffect, useState} from "react";
import ProfilePage from "./profilePage";

export default function ProfileContainer() {

    return(
		<div className="wrapper">
			<ProfilePage />		
		</div>
    )

}