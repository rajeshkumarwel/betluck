import React, { useEffect, useState} from "react";
import FullnamePage from "./fullnamePage";

export default function FullnameContainer() {

    return(
        
		<div className="wrapper">
			<FullnamePage />
		</div>
	
    )

}