import React, { useEffect, useState} from "react";
import WithdrawPage from "./withdrawPage";

export default function WithdrawContainer() {

    return(
		<div className="wrapper">
			<WithdrawPage />		
		</div>
    )

}