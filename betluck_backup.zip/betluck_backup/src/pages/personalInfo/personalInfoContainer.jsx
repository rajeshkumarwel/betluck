import React, { useEffect, useState} from "react";
import PersonalInfoPage from "./personalInfoPage";

export default function PersonalInfoContainer() {

    return(
		<div className="wrapper">
			<PersonalInfoPage />		
		</div>
    )

}