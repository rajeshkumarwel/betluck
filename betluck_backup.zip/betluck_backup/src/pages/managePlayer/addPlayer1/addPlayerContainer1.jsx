import React, { useEffect, useState} from "react";
import AddPlayerPage1 from "./addPlayerPage1";

export default function AddPlayerContainer1() {

    return(
		<div className="wrapper">
			<AddPlayerPage1 />		
		</div>
    )

}