import React, { useEffect, useState} from "react";
import ManagePlayerPage from "./managePlayerPage";

export default function ManagePlayerContainer() {

    return(
		<div className="wrapper">
			<ManagePlayerPage />		
		</div>
    )

}