import React, { useEffect, useState} from "react";
import ManagePlayerPage2 from "./managePlayerPage2";

export default function ManagePlayerContainer2() {

    return(
		<div className="wrapper">
			<ManagePlayerPage2 />		
		</div>
    )

}