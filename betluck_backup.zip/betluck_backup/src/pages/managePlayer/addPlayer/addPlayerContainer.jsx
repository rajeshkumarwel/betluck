import React, { useEffect, useState} from "react";
import AddPlayerPage from "./addPlayerPage";

export default function AddPlayerContainer() {

    return(
		<div className="wrapper">
			<AddPlayerPage />		
		</div>
    )

}