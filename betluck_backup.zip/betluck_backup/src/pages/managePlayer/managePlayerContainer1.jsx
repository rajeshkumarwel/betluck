import React, { useEffect, useState} from "react";
import ManagePlayerPage1 from "./managePlayerPage1";

export default function ManagePlayerContainer1() {

    return(
		<div className="wrapper">
			<ManagePlayerPage1 />		
		</div>
    )

}