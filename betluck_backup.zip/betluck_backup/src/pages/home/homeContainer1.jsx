import React, { useEffect, useState} from "react";
import HomePage1 from "./homePage1";

export default function HomeContainer1() {

    return(
		<div className="wrapper">
			<HomePage1 />		
		</div>
    )

}