import React, { useEffect, useState} from "react";
import HomePage from "./homePage";

export default function HomeContainer() {

    return(
		<div className="wrapper">
			<HomePage />		
		</div>
    )

}