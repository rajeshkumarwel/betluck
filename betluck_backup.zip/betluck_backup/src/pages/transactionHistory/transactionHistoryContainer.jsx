import React, { useEffect, useState} from "react";
import TransactionHistoryPage from "./transactionHistoryPage";

export default function TransactionContainer() {

    return(
		<div className="wrapper">
			<TransactionHistoryPage />		
		</div>
    )

}