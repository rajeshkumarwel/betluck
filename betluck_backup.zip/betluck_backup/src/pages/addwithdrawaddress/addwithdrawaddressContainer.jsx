import React, { useEffect, useState} from "react";
import AddwithdrawaddressPage from "./addwithdrawaddressPage";

export default function AddwithdrawaddressContainer() {

    return(
        
		<div className="wrapper">
			<AddwithdrawaddressPage />
		</div>
	
    )

}